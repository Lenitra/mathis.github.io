let data = [
  {"titre":"Projet 1",
  "lore":"Description glob'ale du projet !",
  "img1":"images/projet1/i1.png",
  "img2":"images/projet1/i2.png",
  "img3":"images/projet1/i3.png",
  "img4":""},

  {"titre":"Projet 2",
  "lore":"Description globale du projet !",
  "img1":"https://scriptverse.academy/img/tutorials/js-add-remove-class.png",
  "img2":"https://cdn.lynda.com/course/718674/718674-637491221301362093-16x9.jpg",
  "img3":"",
  "img4":""},

]

let dessins = [

  {"img": "https://scriptverse.academy/img/tutorials/js-add-remove-class.png",
  "titre": "Un kikoolol"},

  {"img": "https://scriptverse.academy/img/tutorials/js-add-remove-class.png",
  "titre": "Un dessin 2"},
  
]
